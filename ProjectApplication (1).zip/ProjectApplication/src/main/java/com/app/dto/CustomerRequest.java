/*package com.app.dto;

import com.app.service.ExistingAccount;

public class CustomerRequest {
	String accountHolderFirstName;
	String accountHolderLastName;
	String accountHolderPanNumber;
	long accountHolderAccountNumber;
	public String getAccountHolderFirstName() {
		return accountHolderFirstName;
	}
	public void setAccountHolderFirstName(String accountHolderFirstName) {
		this.accountHolderFirstName = accountHolderFirstName;
	}
	public String getAccountHolderLastName() {
		return accountHolderLastName;
	}
	public void setAccountHolderLastName(String accountHolderLastName) {
		this.accountHolderLastName = accountHolderLastName;
	}
	public String getAccountHolderPanNumber() {
		return accountHolderPanNumber;
	}
	public void setAccountHolderPanNumber(String accountHolderPanNumber) {
		this.accountHolderPanNumber = accountHolderPanNumber;
	}
	public long getAccountHolderAccountNumber() {
		return accountHolderAccountNumber;
	}
	public void setAccountHolderAccountNumber(long accountHolderAccountNumber) {
		this.accountHolderAccountNumber = accountHolderAccountNumber;
	}
	@Override
	public String toString() {
		return "CustomerRequest [accountHolderFirstName=" + accountHolderFirstName + ", accountHolderLastName="
				+ accountHolderLastName + ", accountHolderPanNumber=" + accountHolderPanNumber
				+ ", accountHolderAccountNumber=" + accountHolderAccountNumber + "]";
	}
	public CustomerRequest(String accountHolderFirstName, String accountHolderLastName, String accountHolderPanNumber,
			long accountHolderAccountNumber) {
		super();
		this.accountHolderFirstName = accountHolderFirstName;
		this.accountHolderLastName = accountHolderLastName;
		this.accountHolderPanNumber = accountHolderPanNumber;
		this.accountHolderAccountNumber = accountHolderAccountNumber;
	}
	public CustomerRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public static UserRequest login() {
		// TODO Auto-generated method stub
		return null;
	}

}
*/